package com.pdfprinting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PdfPrintingApplication {
    public static void main(String[] args) {
        SpringApplication.run(PdfPrintingApplication.class, args);
    }
}
